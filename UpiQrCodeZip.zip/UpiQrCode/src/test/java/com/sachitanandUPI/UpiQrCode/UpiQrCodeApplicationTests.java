package com.sachitanandUPI.UpiQrCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpiQrCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
