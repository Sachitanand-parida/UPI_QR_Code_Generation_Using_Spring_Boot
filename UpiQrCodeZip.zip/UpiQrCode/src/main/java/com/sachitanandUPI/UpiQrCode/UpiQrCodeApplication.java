package com.sachitanandUPI.UpiQrCode;

import com.google.zxing.WriterException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

import static com.sachitanandUPI.UpiQrCode.QRCodeService.createQRCode;
import static com.sachitanandUPI.UpiQrCode.QRCodeService.createUpiQrCode;

@SpringBootApplication
public class UpiQrCodeApplication {

	public UpiQrCodeApplication() throws IOException, WriterException {
	}

	public static void main(String[] args) throws IOException, WriterException {
		SpringApplication.run(UpiQrCodeApplication.class, args);

		String upiUrl=createUpiQrCode
				("sachitanand@ybl","sachitanand parida",
						"ONXlPw56947559080080","2","Testing",
						"1erdfsfwe");

		String str=createQRCode(upiUrl,"C:\\Users\\sachi\\Desktop\\qrcode.png");
	}


}
