package com.sachitanandUPI.UpiQrCode;

import com.google.zxing.*;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;


public  class QRCodeService {
    private static final Logger logger = (Logger) LoggerFactory.getLogger(QRCodeService.class);

    private static final Map hintMap = new HashMap<>();
    private  static final String charset = StandardCharsets.UTF_8.name(); // or "ISO-8859-1"
    private static final int size = 350;

    public QRCodeService() {
        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
        hintMap.put(EncodeHintType.CHARACTER_SET, StandardCharsets.UTF_8);
        hintMap.put(EncodeHintType.MARGIN, 1);

        hintMap.put(DecodeHintType.CHARACTER_SET, StandardCharsets.UTF_8);
        hintMap.put(DecodeHintType.PURE_BARCODE, Boolean.TRUE);
        hintMap.put(DecodeHintType.POSSIBLE_FORMATS, EnumSet.allOf(BarcodeFormat.class));
    }

    public static String  createQRCode(String qrCodeData, String filePath) throws WriterException, IOException {
        BitMatrix matrix = new MultiFormatWriter().encode(qrCodeData, BarcodeFormat.QR_CODE, size, size, hintMap);
        MatrixToImageWriter.writeToPath(matrix, "png", Paths.get(filePath));
        return "success";
    }

    public static String createUpiQrCode(String payeeAddress, String payeeName,
                                         String trxNo, String amount,
                                         String purpose, String trxRef) throws IOException, WriterException {
        final String qrCode = UriComponentsBuilder.fromUriString("upi://pay")
                .queryParam("pa", payeeAddress)
                .queryParam("pn", payeeName)
                .queryParam("tn", trxNo)
                .queryParam("tr", trxRef)
                .queryParam("am", amount)
                .queryParam("cu", "INR")
                .queryParam("purpose", purpose)
                .build().encode().toUriString();
        logger.info("UPI QR Code = " + qrCode);
        System.out.println(qrCode);

        return qrCode;
    }
}
